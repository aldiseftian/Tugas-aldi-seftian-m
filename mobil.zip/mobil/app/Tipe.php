<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tipe extends Model
{
    protected $table = 'tipe';

    protected $fillable = [
        'id_jenis',
        'nama',
        'deskripsi',
    ];
    
    public function jenis()
    {
        return $this->belongsTo('App\Jenis', 'id_jenis');   
    }
}
