<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function() {
    return redirect(route('login'));
});
Route::get('/starter', function() {
    return view('starter');
});

Auth::routes(['verify' => false, 'reset' => false]);

Route::middleware('auth')->group(function() {
    Route::get('/dashboard', 'DashboardController@index')->name('dashboard');
    Route::get('/jenis', 'JenisController@index')->name('daftarJenis');
    Route::get('/jenis/create', 'JenisController@create')->name('createJenis');
    Route::post('/jenis/create', 'JenisController@store')->name('storeJenis');
    Route::get('/jenis/{jenis}/edit', 'JenisController@edit')->name('editJenis');
    Route::post('/jenis/{jenis}/edit', 'JenisController@update')->name('updateJenis');
    Route::get('/jenis/{jenis}/delete', 'JenisController@destroy')->name('deleteJenis');
    
    Route::get('/tipe', 'TipeController@index')->name('daftarTipe');
    Route::get('/tipe/create', 'TipeController@create')->name('createTipe');
    Route::post('/tipe/create', 'TipeController@store')->name('storeTipe');
    Route::get('/tipe/{tipe}/edit', 'TipeController@edit')->name('editTipe');
    Route::post('/tipe/{tipe}/edit', 'TipeController@update')->name('updateTipe');
    Route::get('/tipe/{tipe}/delete', 'TipeController@destroy')->name('deleteTipe');
});
