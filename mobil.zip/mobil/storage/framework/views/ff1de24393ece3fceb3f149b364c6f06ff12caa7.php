<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Jenis</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Jenis</a></li>
                        <li class="breadcrumb-item active">Model Mobil</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">

            
            <div class="card">
				<div class="card-header text-right">
					<a href="<?php echo e(route('createJenis')); ?>" class="btn btn-primary" role="Button">Tambah Mobil</a>
				</div>
                <div class="card-body p-0">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Model Jenis</th>
                                <th>Deskripsi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($loop->index + 1); ?></td>
                                <td> <?php echo e($jenis->nama); ?></td>
                                <td> <?php echo e($jenis->deskripsi); ?></td>
                                <td>
                                    <a href="<?php echo e(route('editJenis', ['id' => $jenis->id])); ?>" class="btn btn-success btn-sm" role="button">Edit</a>
                                    <a href="<?php echo e(route('deleteJenis', ['id' => $jenis->id])); ?>" class="btn btn-primary btn-sm" role="button">Hapus</a>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>


        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mobil\resources\views/jenis/index.blade.php ENDPATH**/ ?>