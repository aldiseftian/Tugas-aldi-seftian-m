<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Tipe</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">tipe mobil</a></li>
					<li class="breadcrumb-item active">model</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<?php $__env->startSection('addCss'); ?>
<link rel="stylesheet" href="<?php echo e(asset ('css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addJavascript'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
	$(function(){
		$("#data-table").DataTable()})
</script>	

<script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

<script>
	confirmDelete = function(button){
		var url = $(button).data('url');
		swal({
			'title': 'Konfirmasi Hapus',
			'text':'Apakah Kamu Yakin Ingin Menghapus Data Ini?',
			'dangerMode': true,
			'buttons': true
		}).then(function(value) {
			if (value){
				window.location = url;
			}
		})
}
</script>
<?php $__env->stopSection(); ?>

<!-- Main content -->
<div class="content">
	<div class="container-fluid">
	
		
        <div class="card">
			<div class="card-header text-right">
				<a href="<?php echo e(route('createTipe')); ?>" class="btn btn-primary " role="button">Tambah tipe mobil</a>
			</div>
            <div class= "card-body">
				<table class="table table-bordered mb-0" id="data-table">
					<thead>
						<tr>
							<th>No.</th>
							<th>Nama jenis</th>
							<th>Nama Tipe</th>
							<th>Deskripsi</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $tipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td> <?php echo e($loop->index + 1); ?></td>
							<td> <?php echo e($tipe->nama); ?></td>
							<td> <?php echo e($tipe->jenis ? $tipe->jenis->nama : '-'); ?></td>
							<td> <?php echo e($tipe->deskripsi); ?></td>
							<td>
								<a href="<?php echo e(route('editTipe', ['id' => $tipe->id])); ?>" class="btn btn-success btn-sm" role="button">Edit</a>
								<a onclick="confirmDelete(this)" data-url ="<?php echo e(route('deleteTipe', ['id'=> $tipe->id])); ?>" class="btn btn-danger btn-sm" role="button">Hapus</a>
							</td>
						</tr>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>

				</table>
                
            </div>

        </div>

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mobil\resources\views/tipe/index.blade.php ENDPATH**/ ?>